package Lab04.BTNhom17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtNhom17Application {

	public static void main(String[] args) {
		SpringApplication.run(BtNhom17Application.class, args);
	}

}
